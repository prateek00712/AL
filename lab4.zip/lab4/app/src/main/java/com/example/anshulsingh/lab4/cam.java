package com.example.anshulsingh.lab4;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class cam extends AppCompatActivity {
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cam);
        iv = findViewById(R.id.iv);
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cam, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCOde, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCOde, data);
        //Bundle b = data.getExtras();
        Bitmap bt = (Bitmap)data.getExtras().get("data");
        iv.setImageBitmap(bt);
        boolean success = false;
        Toast.makeText(cam.this, "Sending to SDCard", Toast.LENGTH_LONG).show();
        File sdCardDirectory = Environment.getExternalStorageDirectory();
        File image = new File(sdCardDirectory.getAbsolutePath(), "/testapp/test.jpeg");
        FileOutputStream outStream;
        try{
            outStream = new FileOutputStream(image);
            bt.compress(Bitmap.CompressFormat.JPEG, 90, outStream);
            outStream.flush();
            outStream.close();
            success = true;
        }catch (IOException e){
            e.printStackTrace();
        }
        if(success){
            Toast.makeText(getApplicationContext(), "Image saved with success",
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(),
                    "Error during image saving", Toast.LENGTH_LONG).show();
        }

    }
}

